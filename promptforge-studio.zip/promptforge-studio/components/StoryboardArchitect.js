import React, { useState } from 'react';

const StoryboardArchitect = ({ onGenerate }) => {
  const [images, setImages] = useState([]);
  const [campaignType, setCampaignType] = useState('image');

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 7) {
      alert("Max 7 images allowed.");
      return;
    }
    
    // Convert to Base64 for API
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => [...prev, { 
          name: file.name, 
          base64: reader.result.split(',')[1],
          mime: file.type
        }]);
      };
      reader.readAsDataURL(file);
    });
  };

  const generateCampaign = () => {
    if (images.length < 3) {
      alert("Please upload at least 3 product images.");
      return;
    }

    // Construct the prompt for the AI
    const systemPrompt = `
      You are a Creative Director. I have uploaded ${images.length} images of a product.
      Analyze these images to understand the product's DNA (color, material, shape).
      
      Task: Create a ${campaignType} campaign plan.
      
      ${campaignType === 'image' 
        ? 'Generate 9 distinct image prompts for a series. Vary locations and angles (Hero, Macro, Lifestyle, Urban, Nature, Flat Lay, Abstract, Model Shot, Sale Shot). Keep product identity identical based on analysis.'
        : 'Generate a 4-scene video storyboard with timing sequences (0s-2s Hook, 2s-5s Reveal, 5s-8s Lifestyle, 8s-10s Outro). Include camera movement intensity.'
      }
      
      Output format: List of prompts only.
    `;

    // We send the first image as reference for analysis in this demo
    onGenerate(systemPrompt, images[0].base64, images[0].mime);
  };

  return (
    <div className="card">
      <h2 className="card-header">🎬 Campaign Storyboard</h2>
      
      <div className="input-group">
        <label className="input-label">1. Choose Campaign Type</label>
        <div className="toggle-group">
          <button 
            className={`toggle-btn ${campaignType === 'image' ? 'active' : ''}`}
            onClick={() => setCampaignType('image')}
          >9 Image Series</button>
          <button 
            className={`toggle-btn ${campaignType === 'video' ? 'active' : ''}`}
            onClick={() => setCampaignType('video')}
          >Video Script</button>
          <button 
            className={`toggle-btn ${campaignType === 'both' ? 'active' : ''}`}
            onClick={() => setCampaignType('both')}
          >Both</button>
        </div>
      </div>

      <div className="input-group">
        <label className="input-label">2. Upload Product Images (3-7)</label>
        <div className="file-upload" onClick={() => document.getElementById('fileInput').click()}>
          <input 
            type="file" 
            id="fileInput" 
            multiple 
            accept="image/*" 
            style={{display: 'none'}}
            onChange={handleImageUpload}
          />
          {images.length === 0 
            ? <div>⬆️ Click to upload<br/><span style={{fontSize: '0.8rem', color: 'var(--text-muted)'}}>PNG, JPG (Max 7 images)</span></div>
            : <div style={{color: 'var(--accent)', fontWeight: 'bold'}}>{images.length} Images Selected ✓</div>
          }
        </div>
      </div>

      <button className="btn btn-primary" style={{width: '100%'}} onClick={generateCampaign}>
        🎥 Generate Storyboard
      </button>
    </div>
  );
};

export default StoryboardArchitect;
