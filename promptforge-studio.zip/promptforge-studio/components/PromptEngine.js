import React, { useState } from 'react';

const PromptEngine = ({ onGenerate }) => {
  const [formData, setFormData] = useState({
    model: 'nano',
    type: 'image',
    gender: 'female',
    ethnicity: 'south-asian',
    scene: 'heritage',
    lighting: 'golden-hour',
    camera: '85mm',
    product: '',
    mood: 'cinematic',
    material: 'silk',
    season: 'summer',
    platform: 'instagram'
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const buildPrompt = () => {
    // This constructs the system instruction based on the Visual Engineer PDF
    const systemContext = `
      You are a Visual Prompt Engineer. Generate a prompt for ${formData.model}.
      Output MUST be valid natural language for Nano Banana Pro or syntax specific for others.
      NEVER use "beautiful" or "stunning". Use specific visual descriptors.
      NEVER plastic skin. Always include camera body, lens, lighting.
      
      Details:
      - Subject: ${formData.gender}, ${formData.ethnicity}
      - Context: ${formData.scene}
      - Lighting: ${formData.lighting}
      - Camera: ${formData.camera}
      - Product/Brand: ${formData.product || 'Generic Fashion'}
      - Material: ${formData.material}
      - Vibe: ${formData.mood}
      - Season: ${formData.season}
      - Platform: ${formData.platform}
      
      Output ONLY the prompt text.
    `;
    
    onGenerate(systemContext);
  };

  return (
    <div className="card">
      <h2 className="card-header">🚀 Ad Prompt Generator</h2>
      
      {/* Row 1: Core */}
      <div className="grid-2">
        <div className="input-group">
          <label className="input-label">Model Target</label>
          <select className="select-input" onChange={(e) => handleChange('model', e.target.value)}>
            <option value="nano">Nano Banana Pro</option>
            <option value="midjourney">Midjourney v6.1</option>
            <option value="flux">FLUX</option>
            <option value="sdxl">Stable Diffusion XL</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Output Type</label>
          <div className="toggle-group">
            <button 
              className={`toggle-btn ${formData.type === 'image' ? 'active' : ''}`}
              onClick={() => handleChange('type', 'image')}
            >Image</button>
            <button 
              className={`toggle-btn ${formData.type === 'video' ? 'active' : ''}`}
              onClick={() => handleChange('type', 'video')}
            >Video</button>
          </div>
        </div>
      </div>

      {/* Row 2: Subject & Context */}
      <div className="grid-3">
        <div className="input-group">
          <label className="input-label">Gender</label>
          <select className="select-input" onChange={(e) => handleChange('gender', e.target.value)}>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="non-binary">Non-Binary</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Ethnicity</label>
          <select className="select-input" onChange={(e) => handleChange('ethnicity', e.target.value)}>
            <option value="south-asian">South Asian</option>
            <option value="east-asian">East Asian</option>
            <option value="caucasian">Caucasian</option>
            <option value="african">African</option>
            <option value="middle-eastern">Middle Eastern</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Scene Context</label>
          <select className="select-input" onChange={(e) => handleChange('scene', e.target.value)}>
            <option value="heritage">Heritage (Haveli/Mughal)</option>
            <option value="urban">Urban Street</option>
            <option value="studio">Studio Minimal</option>
            <option value="nature">Nature/Outdoor</option>
            <option value="luxury">Luxury Interior</option>
          </select>
        </div>
      </div>

      {/* Row 3: Camera & Light */}
      <div className="grid-2">
        <div className="input-group">
          <label className="input-label">Lighting Style</label>
          <select className="select-input" onChange={(e) => handleChange('lighting', e.target.value)}>
            <option value="golden-hour">Golden Hour (Warm)</option>
            <option value="neon">Neon Noir (Cyberpunk)</option>
            <option value="softbox">Studio Softbox</option>
            <option value="rembrandt">Rembrandt (Dramatic)</option>
            <option value="moonlight">Moonlight (Cold)</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Camera/Lens</label>
          <select className="select-input" onChange={(e) => handleChange('camera', e.target.value)}>
            <option value="85mm">85mm Portrait (Bokeh)</option>
            <option value="35mm">35mm Street (Natural)</option>
            <option value="24mm">24mm Wide (Context)</option>
            <option value="100mm">100mm Macro (Detail)</option>
          </select>
        </div>
      </div>

      {/* Row 4: Ad Specifics */}
       <div className="grid-3">
        <div className="input-group">
          <label className="input-label">Material</label>
          <select className="select-input" onChange={(e) => handleChange('material', e.target.value)}>
            <option value="silk">Silk</option>
            <option value="cotton">Cotton/Lawn</option>
            <option value="denim">Denim</option>
            <option value="leather">Leather</option>
            <option value="velvet">Velvet</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Season</label>
          <select className="select-input" onChange={(e) => handleChange('season', e.target.value)}>
            <option value="summer">Summer</option>
            <option value="winter">Winter</option>
            <option value="festive">Festive/Eid</option>
          </select>
        </div>
        <div className="input-group">
          <label className="input-label">Platform</label>
          <select className="select-input" onChange={(e) => handleChange('platform', e.target.value)}>
            <option value="instagram">Instagram (Square)</option>
            <option value="tiktok">TikTok (Vertical 9:16)</option>
            <option value="linkedin">LinkedIn (Professional)</option>
          </select>
        </div>
       </div>

       {/* Product Name */}
       <div className="input-group">
          <label className="input-label">Product / Brand Name (Optional)</label>
          <input 
            type="text" 
            className="text-input" 
            placeholder="e.g. Sana Safinaz Lawn 2026"
            onChange={(e) => handleChange('product', e.target.value)}
          />
       </div>

      <button className="btn btn-primary" style={{width: '100%', marginTop: '1rem'}} onClick={buildPrompt}>
        ⚡ Generate Prompt
      </button>
    </div>
  );
};

export default PromptEngine;
