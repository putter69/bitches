import React, { useState } from 'react';

const AvatarArchitect = ({ onGenerate }) => {
  const [avatar, setAvatar] = useState({
    gender: 'Female',
    age: 'Young Adult',
    skin: 'Medium',
    eyes: 'Brown',
    hair: 'Long Wavy',
    expression: 'Neutral',
    features: 'Natural'
  });

  const options = {
    gender: ['Female', 'Male', 'Non-Binary'],
    age: ['Teen', 'Young Adult', 'Adult', 'Mature'],
    skin: ['Fair', 'Light', 'Medium', 'Tan', 'Deep'],
    eyes: ['Brown', 'Black', 'Blue', 'Green'],
    hair: ['Long Straight', 'Long Wavy', 'Short', 'Curly', 'Bald'],
    expression: ['Neutral', 'Smiling', 'Intense', 'Laughing'],
    features: ['Natural', 'Freckles', 'Acne Scars', 'Wrinkles']
  };

  const buildAvatarPrompt = () => {
    const prompt = `
      Generate a hyper-realistic avatar prompt for ${avatar.gender}, ${avatar.age}, ${avatar.skin} skin tone.
      Eyes: ${avatar.eyes}. Hair: ${avatar.hair}. Expression: ${avatar.expression}.
      Special features: ${avatar.features}.
      
      CRITICAL RULES:
      - Include "visible pores, subsurface scattering, hyperrealistic, 8k, shot on Sony A7R IV, 85mm lens".
      - NO plastic skin, NO ring light reflection.
      - Center frame, looking at camera.
      
      Output ONLY the prompt.
    `;
    onGenerate(prompt);
  };

  return (
    <div className="card">
      <h2 className="card-header">👤 Hyper-Real Avatar Architect</h2>
      <p style={{color: 'var(--text-muted)', marginBottom: '1.5rem'}}>Select options to build your model identity.</p>

      {Object.keys(options).map((category) => (
        <div key={category} style={{marginBottom: '1rem'}}>
          <label className="input-label">{category.charAt(0).toUpperCase() + category.slice(1)}</label>
          <div className="toggle-group" style={{flexWrap: 'wrap'}}>
            {options[category].map((opt) => (
              <button
                key={opt}
                className={`toggle-btn ${avatar[category] === opt ? 'active' : ''}`}
                onClick={() => setAvatar(prev => ({...prev, [category]: opt}))}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      ))}

      <button className="btn btn-primary" style={{width: '100%', marginTop: '1rem'}} onClick={buildAvatarPrompt}>
        Generate Avatar Prompt
      </button>
    </div>
  );
};

export default AvatarArchitect;
