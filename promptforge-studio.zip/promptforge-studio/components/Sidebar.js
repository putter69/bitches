import React from 'react';

const Sidebar = ({ activeTab, setActiveTab, isOpen, setIsOpen }) => {
  
  const menuItems = [
    { id: 'generator', label: 'Prompt Engine', icon: '⚡' },
    { id: 'avatar', label: 'Avatar Architect', icon: '👤' },
    { id: 'storyboard', label: 'Storyboard', icon: '🎬' },
    { id: 'deconstruct', label: 'De-Constructor', icon: '🔍' },
  ];

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <span>⚡</span> PromptForge
      </div>
      
      <nav>
        {menuItems.map((item) => (
          <div 
            key={item.id}
            className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => {
              setActiveTab(item.id);
              if(window.innerWidth < 768) setIsOpen(false);
            }}
          >
            <span>{item.icon}</span> {item.label}
          </div>
        ))}
      </nav>
      
      <div style={{ marginTop: 'auto', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
        v1.0.0 Pro
      </div>
    </div>
  );
};

export default Sidebar;
