import Head from 'next/head';
import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import PromptEngine from '../components/PromptEngine';
import AvatarArchitect from '../components/AvatarArchitect';
import StoryboardArchitect from '../components/StoryboardArchitect';

export default function Home() {
  const [activeTab, setActiveTab] = useState('generator');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [output, setOutput] = useState("Your generated prompt will appear here...");
  const [loading, setLoading] = useState(false);

  // The Core API Caller
  const handleGenerate = async (promptText, imageBase64 = null, mimeType = null) => {
    setLoading(true);
    setOutput("⏳ Thinking...");

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: promptText,
          imageBase64: imageBase64,
          mimeType: mimeType
        })
      });

      const data = await response.json();

      if (data.result) {
        setOutput(data.result);
        // Save to local storage history
        const history = JSON.parse(localStorage.getItem('promptHistory') || '[]');
        history.unshift({ prompt: promptText, result: data.result, date: new Date().toISOString() });
        localStorage.setItem('promptHistory', JSON.stringify(history.slice(0, 10))); // Keep last 10
      } else {
        setOutput(`Error: ${data.error}`);
      }
    } catch (error) {
      console.error(error);
      setOutput("Connection error. Check console.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    alert("Prompt copied to clipboard!");
  };

  return (
    <div className="app-container">
      <Head>
        <title>PromptForge Studio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Head>

      {/* Sidebar Navigation */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isOpen={isSidebarOpen} 
        setIsOpen={setIsSidebarOpen} 
      />

      {/* Main Content Area */}
      <main className="main-content">
        
        {/* Mobile Header */}
        <div className="mobile-header" style={{display: 'none'}}>
           <button className="hamburger" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>☰</button>
           <h2>PromptForge</h2>
           <div style={{width: '30px'}}></div>
        </div>

        {/* Dynamic View Rendering */}
        <div style={{maxWidth: '1200px', margin: '0 auto'}}>
          
          {activeTab === 'generator' && (
            <div className="grid-2" style={{gap: '2rem'}}>
              <div>
                <PromptEngine onGenerate={handleGenerate} />
              </div>
              <div>
                <div className="card" style={{height: '100%'}}>
                  <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '1rem'}}>
                    <h3>📄 Output</h3>
                    <button className="btn btn-secondary" onClick={copyToClipboard}>Copy</button>
                  </div>
                  <div className="output-box" style={{minHeight: '400px'}}>
                    {loading ? <span style={{color: 'var(--accent)'}}>Generating...</span> : output}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'avatar' && (
            <div className="grid-2" style={{gap: '2rem'}}>
                <AvatarArchitect onGenerate={handleGenerate} />
                <div className="card">
                    <h3>👤 Avatar Preview</h3>
                     <div className="output-box" style={{minHeight: '300px', marginTop: '1rem'}}>
                        {loading ? "Generating..." : output}
                    </div>
                </div>
            </div>
          )}

          {activeTab === 'storyboard' && (
             <div className="grid-2" style={{gap: '2rem'}}>
                <StoryboardArchitect onGenerate={handleGenerate} />
                 <div className="card">
                    <h3>🎬 Campaign Plan</h3>
                     <div className="output-box" style={{minHeight: '300px', marginTop: '1rem'}}>
                        {loading ? "Analyzing product..." : output}
                    </div>
                </div>
             </div>
          )}

           {activeTab === 'deconstruct' && (
             <div className="card">
                <h2>🔍 Visual De-Constructor</h2>
                <p style={{color: 'var(--text-muted)', marginBottom: '1rem'}}>Upload an image to reverse-engineer its prompt.</p>
                <div className="file-upload" style={{marginBottom: '1rem'}}>
                     <p>Click to upload inspiration image</p>
                </div>
                <button className="btn btn-primary">Analyze Image</button>
             </div>
           )}

        </div>
      </main>

      {/* CSS for Mobile Header Override */}
      <style jsx global>{`
        @media (max-width: 768px) {
          .mobile-header {
            display: flex !important;
          }
          .grid-2 {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
