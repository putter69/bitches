import { GoogleGenerativeAI } from "@google/generative-ai";

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { prompt, imageBase64, mimeType } = req.body;

    // Initialize the Gemini Client using the Secret Key from environment variables
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    
    // Use Gemini 2.5 Flash-Lite for speed and high limits
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-lite" });

    const generationConfig = {
      temperature: 0.7,
      topK: 1,
      topP: 1,
      maxOutputTokens: 2048,
    };

    // Prepare content parts
    const parts = [];
    
    // Add text prompt
    parts.push({ text: prompt });

    // Add image if provided (for Storyboard & De-constructor)
    if (imageBase64 && mimeType) {
      parts.push({
        inlineData: {
          data: imageBase64,
          mimeType: mimeType
        }
      });
    }

    const result = await model.generateContent({
      contents: [{ role: "user", parts }],
      generationConfig,
    });

    const response = await result.response;
    const text = response.text();

    res.status(200).json({ result: text });

  } catch (error) {
    console.error("API Error:", error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
}
